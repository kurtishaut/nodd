import { Component, OnInit } from '@angular/core';
import { User } from '../../models/User';
import { FlashMessagesService } from 'angular2-flash-messages';
import { Router } from '@angular/router';
import { UserService } from '../../services/user.service';
import { SettingsService } from '../../services/settings.service';

@Component({
  selector: 'app-add-connection',
  templateUrl: './add-connection.component.html',
  styleUrls: ['./add-connection.component.css']
})
export class AddConnectionComponent implements OnInit {
  
  user: User = {
    dbName: '',
    /*lastName: '',
    email: '',
    phone: '',
    role: '',
    score: 0*/
  }

  /*disableScoreOnAdd: boolean;*/
  
  constructor(
    private flashMessagesService: FlashMessagesService,
    private router: Router,
    private userService: UserService,
    private settingsService: SettingsService
  ) { }

  ngOnInit() {
    /*this.disableScoreOnAdd = this.settingsService.getSettings().disableScoreOnAdd;*/
  }

  onSubmit({value, valid}: {value: User, valid: boolean}) {
    /*if(this.disableScoreOnAdd){
      value.score = 0;
    }*/
    if(!valid){
      this.flashMessagesService.show('Please fill in all fields', {
        cssClass: 'alert-danger', timeout: 4000
      });
      this.router.navigate(['add-connection']);
    } else {
      this.userService.addNewConnection(value);
      this.flashMessagesService.show('New database added', {
        cssClass: 'alert-success', timeout: 4000
      });
      this.router.navigate(['/']);
    }
  }
}
