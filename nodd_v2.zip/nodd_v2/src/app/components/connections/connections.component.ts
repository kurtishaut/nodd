import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user.service';
import { User } from '../../models/User';

@Component({
  selector: 'app-connections',
  templateUrl: './connections.component.html',
  styleUrls: ['./connections.component.css']
})
export class ConnectionsComponent implements OnInit {
  users: any[];
  totalConnections: number;

  constructor(private userService: UserService) { }

  ngOnInit() {
    this.userService.getUsers().subscribe(users => {
      //console.log(users);
      this.users = users;
      this.getTotalConnections();
    });
    
  }

  getTotalConnections(){
    let total = 0;
    for(let i=0; i<this.users.length; i++){
      total += 1;
    }
    this.totalConnections = total;
  }

}
