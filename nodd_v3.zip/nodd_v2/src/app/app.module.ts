//module imports
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { FlashMessagesModule } from 'angular2-flash-messages';
import { HttpClientModule } from "@angular/common/http";


//database imports
import { AngularFireModule } from 'angularfire2';
import { AngularFireDatabaseModule, AngularFireDatabase } from 'angularfire2/database';
import { AngularFireAuthModule } from 'angularfire2/auth';
//environment import
import { environment } from '../environments/environment';

//components
import { AppComponent } from './app.component';
import { RegisterComponent } from './components/register/register.component';
import { LoginComponent } from './components/login/login.component';
import { ProfileComponent } from './components/profile/profile.component';
import { SettingsComponent } from './components/settings/settings.component';
import { HomeComponent } from './components/home/home.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { ConnectionsComponent } from './components/connections/connections.component';
import { AddConnectionComponent } from './components/add-connection/add-connection.component';
import { ProfileConnectionComponent } from './components/profile-connection/profile-connection.component';
import { EditConnectionComponent } from './components/edit-connection/edit-connection.component';
import { NavComponent } from './components/nav/nav.component';


//services
import { UserService } from './services/user.service';
import { FlashMessagesService } from 'angular2-flash-messages';
import { AuthService } from './services/auth.service';
import { SettingsService } from './services/settings.service';
import { BackendService } from './services/backend.service';

//Guards
import { AuthGuard } from './guards/auth.guard';
import { RegisterGuard } from './guards/register.guard';



//routes
const appRoutes: Routes = [
  {path:'', component: HomeComponent, canActivate:[AuthGuard]},
  {path:'register', component: RegisterComponent, canActivate:[RegisterGuard]},
  {path: 'login', component: LoginComponent},
  {path:'add-connection', component: AddConnectionComponent, canActivate:[AuthGuard]},
  {path:'user/:id', component: ProfileConnectionComponent, canActivate:[AuthGuard]},
  {path:'edit-connection/:id', component: EditConnectionComponent, canActivate:[AuthGuard]},
  {path:'settings', component: SettingsComponent, canActivate:[AuthGuard]},
  {path:'nav', component: NavComponent, canActivate:[AuthGuard]}
  
]

@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    LoginComponent,
    ProfileComponent,
    SettingsComponent,
    HomeComponent,
    NavbarComponent,
    ConnectionsComponent,
    AddConnectionComponent,
    ProfileConnectionComponent,
    EditConnectionComponent,
    NavComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    FlashMessagesModule,
    RouterModule.forRoot(appRoutes),
    AngularFireModule.initializeApp(environment.firebase, 'clientpanel'),
    AngularFireAuthModule,
    HttpClientModule
  ],
  providers: [
    AngularFireDatabase,
    AngularFireDatabaseModule,
    FlashMessagesService,
    UserService,
    AuthService,
    SettingsService,
    AuthGuard,
    RegisterGuard,
    BackendService

  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
