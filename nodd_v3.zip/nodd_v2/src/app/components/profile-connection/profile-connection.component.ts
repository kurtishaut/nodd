import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user.service';
import { FlashMessagesService } from 'angular2-flash-messages';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { User } from '../../models/User';

@Component({
  selector: 'app-profile-connection',
  templateUrl: './profile-connection.component.html',
  styleUrls: ['./profile-connection.component.css']
})
export class ProfileConnectionComponent implements OnInit {
  id: string;
  user: User;
  /*showScoreUpdateInput: boolean = false;*/

  constructor(
    private userService: UserService,
    private router: Router,
    private route: ActivatedRoute,
    private flashMessagesService: FlashMessagesService
  ) { }

  ngOnInit() {
    //Get id from url
    this.id = this.route.snapshot.params['id'];
    //Get client
    this.userService.getConnection(this.id).subscribe(user => {
      this.user = user;
      console.log(this.user);
    });
  }

  /*updateScore(id:string){
    this.userService.updateConnection(this.id, this.user);
    this.flashMessagesService.show('Score Updated', {
      cssClass: 'alert-success', timeout: 4000
    });
    this.router.navigate(['/user/'+this.id]);
  }*/

  onDeleteClick(){
    if(confirm("Are you sure you want to delete this database?")){
      this.userService.deleteConnection(this.id);
      this.flashMessagesService.show('Connection Removed', {
        cssClass: 'alert-success', timeout: 4000
      });
      this.router.navigate(['/']);
    }
  }

}
