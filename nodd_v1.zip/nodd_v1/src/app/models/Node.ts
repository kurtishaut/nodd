export interface Node {
    id?: number;
    word?: string; /**Represents average word using all vectors from dataset graph */
    clicked?: boolean; /**When node is clicked, will set this value to true and call function to add node id to user list */
    connectedNodes?: any[]; /** Each node will keep a list of the IDs of nodes that it is directly connected to */
    isDataset?: boolean; /**if the node is a leaf node in the org. aka dataset, and is clicked, will take user to preview and give opportunity to mark */

    /**Send connectedNodes list for prior update immediately upon click? */
}