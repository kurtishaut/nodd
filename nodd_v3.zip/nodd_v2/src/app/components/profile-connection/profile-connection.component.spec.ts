import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfileConnectionComponent } from './profile-connection.component';

describe('ProfileConnectionComponent', () => {
  let component: ProfileConnectionComponent;
  let fixture: ComponentFixture<ProfileConnectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProfileConnectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProfileConnectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
