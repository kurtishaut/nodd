import { Component, OnInit } from '@angular/core';
import { FlashMessagesService } from 'angular2-flash-messages';
import { Router } from '@angular/router';
import { User } from '../../models/User';
import { Node } from '../../models/Node';
import { BackendService } from '../../services/backend.service';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})

export class NavComponent implements OnInit {

  user: User; //The user of the application
  org: Node[]; //The organization is a list of nodes
  sizeOfOrg: number; // the number of nodes in the org list, used to prevent index out of bounds requests
  curNode: Node; // this is the node in the center of user screen (where they are in the organization)
  leftNode: Node; // this is the node to the left of the cur node
  rightNode: Node; // this is the node to the right of the cur node
  midNode: Node; // this is the node in the middle and down relative to cur node
  // keep track of indexes for computing future views based off clicks
  leftNodeID: number;
  rightNodeID: number;
  midNodeID: number;

  constructor(
    private flashMessagesService: FlashMessagesService,
    private router: Router,
    private backendService: BackendService
    ) {
    this.user = {
      nodesClicked:[],
      dbMarked:[]
    }
    this.org = this.backendService.getOrg();
    this.sizeOfOrg = this.org.length;
    this.curNode = this.org[0];
    this.leftNode = this.org[1];
    this.rightNode = this.org[2];
    this.midNode = this.org[3];


   }

  ngOnInit() {
   console.log((this.sizeOfOrg));
  }

  /**when a node is clicked, call this method */
  nodeClicked(nodeID:number) {
    this.org[nodeID].clicked = true; // change value for the organization itself
    this.user.nodesClicked.push(nodeID);
    console.log(this.org, this.org[nodeID].clicked);
    console.log(this.user.nodesClicked);
    //create new view with the clicked nodde as the current position/current node
    //calculate indexes of "mountains"
    
    this.computeIndex(nodeID);
    this.createView(nodeID, this.leftNodeID, this.rightNodeID, this.midNodeID);
    //Create new view
    

  }

  computeIndex(nodeID:number){
    this.leftNodeID = (2*nodeID+1);
    this.rightNodeID = (2*nodeID);
    this.midNodeID = (4*nodeID);
    //index checking, implement more random selection of leaf nodes later
    if(this.leftNodeID > this.sizeOfOrg){
      this.leftNodeID = this.sizeOfOrg;                                    
    }
    if(this.rightNodeID > this.sizeOfOrg){
      this.rightNodeID = this.sizeOfOrg;
    }
    if(this.midNodeID > this.sizeOfOrg){
      this.midNodeID = this.sizeOfOrg;
    }
  }

  createView(curNodeID:number, leftNodeID:number, rightNodeID:number, midNodeID:number){
    this.curNode = this.org[curNodeID];
    this.leftNode = this.org[this.leftNodeID];
    this.rightNode = this.org[this.rightNodeID];
    this.midNode = this.org[this.midNodeID];

  }

  /**Adds dataset node id to list of marked datasets for the user 
   * directs user to add connection page to add the database connection
  */
  datasetMarked(nodeID:number){
    console.log("dataset marked!", nodeID);
    this.user.dbMarked.push(nodeID); // add nodeID to marked datasets list
    console.log(this.user.dbMarked)
    this.router.navigate(['add-connection']); //navigate user to add the database connection
  
  }

  /**Does not add the database to list of marked datasets
   * Redirects user to root of organization
   */
  datasetNotMarked(){
    console.log("dataset NOT marked!")
    this.curNode = this.org[0];
    this.leftNode = this.org[1];
    this.rightNode = this.org[2];
    this.midNode = this.org[3];
    //this.router.navigate(['nav']); //navigate user to add the database connection
  }

}
