export interface User {
    key?:string;
    dbName?:string; /*used for adding datasets */
    nodesClicked?: any[]; /*stores id of all nodes clicked during navigation*/
    dbMarked?: any[]; /*stores id of all databases that were marked by user */
    /*lastName?:string;
    email?:string;
    phone?:string;
    role?:string;
    score?:number; */
}