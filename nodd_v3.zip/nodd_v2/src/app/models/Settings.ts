export interface Settings {
    allowRegistration?: boolean;
    disableScoreOnAdd?: boolean;
    disableScoreOnEdit?: boolean;
}