export interface Node {
    ID?: number;
    NodeName: string;
    ParentIDs: number[];
    ChildIDs: number[];
    // word?: string; /**Represents average word using all vectors from dataset graph */
    // clicked?: boolean; /**When node is clicked, will set this value to true and call function to add node id to user list */
    isDataset?: boolean; /**if the node is a leaf node in the org. aka dataset, and is clicked, will take user to preview and give opportunity to mark */
    /**Send connectedNodes list for prior update immediately upon click? */
}