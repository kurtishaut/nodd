import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user.service';
import { FlashMessagesService } from 'angular2-flash-messages';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { User } from '../../models/User';
import { SettingsService } from '../../services/settings.service';

@Component({
  selector: 'app-edit-connection',
  templateUrl: './edit-connection.component.html',
  styleUrls: ['./edit-connection.component.css']
})
export class EditConnectionComponent implements OnInit {
  id: string;
  user: User = {
    dbName: '',
    /*lastName: '',
    email: '',
    phone: '',
    role: '',
    score: 0*/
  }

  /*disableScoreOnEdit: boolean;*/

  constructor(
    private userService: UserService,
    private router: Router,
    private route: ActivatedRoute,
    private flashMessagesService: FlashMessagesService,
    private settingsService: SettingsService
  ) { }

  ngOnInit() {
    this.id = this.route.snapshot.params['id'];
    //Get Client
    this.userService.getConnection(this.id).subscribe(user => {
      this.user = user;
    });

    /*this.disableScoreOnEdit = this.settingsService.getSettings().disableScoreOnEdit;*/
  }

  onSubmit({value, valid}: {value: User, valid: boolean}) {
    if(!valid){
      this.flashMessagesService.show('Please fill in all fields', {
        cssClass: 'alert-danger', timeout: 4000
      });
      this.router.navigate(['edit-connection/'+this.id]);
    } else {
      //update the connection
      this.userService.updateConnection(this.id, value);
      this.flashMessagesService.show('Connection Updated', {
        cssClass: 'alert-success', timeout: 4000
      });
      this.router.navigate(['/user/'+this.id]);
    }
  }

}
