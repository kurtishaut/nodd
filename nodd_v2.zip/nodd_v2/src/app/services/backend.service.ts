import { Injectable } from '@angular/core';
import { stringify } from 'querystring';
import { HttpClient } from "@angular/common/http";
import { Observable } from 'rxjs/Observable';
import { Node } from '../models/Node';


@Injectable()
export class BackendService {

  /**Define endpoint for where endpoint of server is located */
  API_URL = 'http://localhost:8080/navigation';
  
  
  // databaseRef: NameOfImport<any>; // connection to database backend

  org: Observable<Node[]>; //Assuming this will be a list of node_IDs in a specific order representing organizational structure, this will be what is rendered on users screen

  /**Dummy values for testing purposes */
  // n0: Node;
  // n1: Node;
  // n2: Node;
  // n3: Node;
  // n4: Node;
  // n5: Node;
  // n6: Node;
  // n7: Node;
  // n8: Node;
  // n9: Node;
  // n10: Node;
  // n11: Node;
  // n12: Node;
  // nodesList: Node[];

  constructor(private http: HttpClient) {



    // this.n0 = {
    //   id:0,
    //   word:"Education",
    //   clicked:false,
    //   connectedNodes:[this.n1, this.n2],
    //   isDataset:false
    // }

    // this.n1 = {
    //   id:1,
    //   word:"English",
    //   clicked:false,
    //   connectedNodes:[this.n0, this.n3],
    //   isDataset:false
    // }
    
    // this.n2 = {
    //   id:2,
    //   word:"Science",
    //   clicked:false,
    //   connectedNodes:[this.n0, this.n3],
    //   isDataset:false
    // }

    // this.n3 = {
    //   id:3,
    //   word:"Social Studies",
    //   clicked:false,
    //   connectedNodes:[this.n1, this.n2],
    //   isDataset:false
    // }

    // this.n4 = {
    //   id:4,
    //   word:"Home Economics",
    //   clicked:false,
    //   connectedNodes:[this.n1, this.n2],
    //   isDataset:false
    // }

    // this.n5 = {
    //   id:5,
    //   word:"Chorus",
    //   clicked:false,
    //   connectedNodes:[this.n1, this.n2],
    //   isDataset:false
    // }

    // this.n6 = {
    //   id:6,
    //   word:"Accounting",
    //   clicked:false,
    //   connectedNodes:[this.n1, this.n2],
    //   isDataset:false
    // }

    // this.n7 = {
    //   id:7,
    //   word:"Arts and Crafts",
    //   clicked:false,
    //   connectedNodes:[this.n1, this.n2],
    //   isDataset:true
    // }

    // this.n8 = {
    //   id:8,
    //   word:"Band",
    //   clicked:false,
    //   connectedNodes:[this.n1, this.n2],
    //   isDataset:true
    // }

    // this.n9 = {
    //   id:9,
    //   word:"Debate Club",
    //   clicked:false,
    //   connectedNodes:[this.n1, this.n2],
    //   isDataset:true
    // }

    // this.n10 = {
    //   id:10,
    //   word:"Theater and Dance",
    //   clicked:false,
    //   connectedNodes:[this.n1, this.n2],
    //   isDataset:true
    // }

    // this.n11 = {
    //   id:11,
    //   word:"public speaking",
    //   clicked:false,
    //   connectedNodes:[this.n1, this.n2],
    //   isDataset:true
    // }

    // this.n12 = {
    //   id:12,
    //   word:"Sports",
    //   clicked:false,
    //   connectedNodes:[this.n1, this.n2],
    //   isDataset:true
    // }

    // this.nodesList = [this.n0, this.n1, this.n2, this.n3, this.n4, this.n5, this.n6, this.n7, this.n8, this.n9, this.n10, this.n11, this.n12]
  }

  /** Returns the root of the Organization */ 
  getRoot(): Observable<Node> {
    return this.http.get<Node>(this.API_URL + '/get-root');
  }

  /**Returns a Node based on ID */
  getNode(id:number): Observable<Node> {
    return this.http.get<Node>(this.API_URL + '/get-node/' + id);
  }



  /*
  constructor(private db: DatabaseImport) { 
    this.databaseRef = this.db.org;
    this.org = this.databaseRef.snapshotChanges().map(changes => {
      return changes.map(c => ({ key: c.payload.key, ...c.payload.val() }));
    });
  }
  */

  /**Returns the organization to the component rendered on users screen */
  getOrg(){
    //return this.org;
    return this.nodesList;
  }

  /**Updates the prior probabilities of the organization based on Nodes clicked by user */
  updateOrgNodesClicked(nodesClicked: any[]){
    //this.databaseRef.updatePriorClicked(nodesClicked);

  }

  /**Updates the prior probabilites of the organization based on datasets marked by user */
  updateOrgDBMarked(dbMarked: any[]) {
    //this.databaseRef.updatePriorMarked(nodesClicked);
  }

  /**Gets the word representation of a node in the organization */
  getWord(nodeID: number){
    //return thisdatabaseRef.getWord(nodeID);
    
  }

  /**Finds out if node is a dataset (leaf node) */
  isDataset(nodeID: number){
    //return this.databaseRef.isLeaf(nodeID);
  }

}
