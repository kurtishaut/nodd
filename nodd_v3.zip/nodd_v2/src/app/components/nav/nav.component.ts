import { Component, OnInit } from '@angular/core';
import { FlashMessagesService } from 'angular2-flash-messages';
import { Router } from '@angular/router';
import { User } from '../../models/User';
import { Node } from '../../models/Node';
import { Observable } from 'rxjs/Observable';
import { BackendService } from '../../services/backend.service';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})

export class NavComponent implements OnInit {

  user: User; //The user of the application
  org: Node[]; // organization is an array of nodes
  sizeOfOrg: number; // the number of nodes in the org list, used to prevent index out of bounds requests
  
  curNode: Node; // this is the node in the center of user screen (where they are in the organization)
  numChildren: number; // this will be equal to the size of the ChildIDs array served up from back-end 
  nodeChild1: Node; 
  nodeChild2: Node;
  nodeChild3: Node; 
  nodeChild4: Node; 
  nodeChild5: Node;
  nodeChild6: Node; 
  nodeLookLeft: Node;
  nodeLookRight: Node;
  testNode: Node;
  

  root: Node;
  getLeftNodeTest: Node;
  childrenTemp: number[];
  leftNodePtr: number;
  rightNodePtr: number;

  
  
  // keep track of indexes for computing future views based off clicks
  leftNodeID: number;
  rightNodeID: number;
  midNodeID: number;

  constructor(
    private flashMessagesService: FlashMessagesService,
    private router: Router,
    private backendService: BackendService
    ) {
    this.user = {
      nodesClicked:[],
      dbMarked:[]
    }
    //this.org = this.backendService.getOrg();
    //this.sizeOfOrg = this.org.length;
    
    //this.midNode = this.org[3];


   }

  ngOnInit() {
    //this.org = this.backendService.getOrg();
    this.backendService.getRoot()
        .subscribe(root => this.root = root);
    console.log("Got root", this.root)
    this.curNode = this.getNode(98);
    //this.curNode.isDataset = false;
    console.log("This is the current node:", this.curNode);
    //this.createView(this.curNode);
    //this.isDataset(this.curNode);
    /**
    this.nodeChild1 = this.org[1];
    this.nodeChild2 = this.org[2];
    this.nodeChild3 = this.org[3];
    this.nodeChild4 = this.org[4];
    this.nodeChild5 = this.org[5];
    this.nodeChild6 = this.org[6];
    this.nodeLookLeft = this.org[7];
    this.nodeLookRight = this.org[8];  */
    

    /** 
    this.backendService.getRoot()
        .subscribe(root => this.root = root);
    console.log("Got root", this.root) */
    //this.getOrg(this.root);
    //this.sizeOfOrg - this.org.length;
    //this.curNode = this.org[0];
    //this.leftNode = this.org[1];
    //this.rightNode = this.org[2];
    //this.backendService.getNode(6599)
        //.subscribe(node => this.getLeftNodeTest = node);
    //console.log("This is the root: ", this.root.ID);

   //console.log((this.sizeOfOrg));
  }

  /** Checks if the cur node is a dataset or not, 
   * may have to change conditional to check the length of ChildIDs array
   */
  isDataset(node:Node) {
    if(node.ChildIDs == null) {
      node.isDataset = true;
    } else {
      node.isDataset = false;
    }
  }

  /**Following method creates the view based on the curNode */
  createView(node:Node) {
    //this.isDataset(node); // find out if this node is a dataset, set its boolean value to control the view 
    this.curNode = node;
    this.numChildren = node.ChildIDs.length; // findout how many children this has 
    console.log(node);
    console.log(this.numChildren);
    
    /**Hack through this... 6 conditions ugh! Need to also set other childNode values to null*/
    /**
    if ( this.numChildren == 1) { // one child case
      this.nodeChild1 = this.getNode(node.ChildIDs[0]);
      this.nodeChild2 = null;
      this.nodeChild3 = null;
      this.nodeChild4 = null;
      this.nodeChild5 = null;
      this.nodeChild6 = null;
    } else if (this.numChildren == 2) { // two child case
      this.nodeChild1 = this.getNode(node.ChildIDs[0]);
      this.nodeChild2 = this.getNode(node.ChildIDs[1]);
      this.nodeChild3 = null;
      this.nodeChild4 = null;
      this.nodeChild5 = null;
      this.nodeChild6 = null;
    } else if (this.numChildren == 3) { // three child case
      this.nodeChild1 = this.getNode(node.ChildIDs[0]);
      this.nodeChild2 = this.getNode(node.ChildIDs[1]);
      this.nodeChild3 = this.getNode(node.ChildIDs[2]);
      this.nodeChild4 = null;
      this.nodeChild5 = null;
      this.nodeChild6 = null;
    } else if (this.numChildren == 4) { // four child case
      this.nodeChild1 = this.getNode(node.ChildIDs[0]);
      this.nodeChild2 = this.getNode(node.ChildIDs[1]);
      this.nodeChild3 = this.getNode(node.ChildIDs[2]);
      this.nodeChild4 = this.getNode(node.ChildIDs[3]);
      this.nodeChild5 = null;
      this.nodeChild6 = null;
    } else if (this.numChildren == 5) { // five child case
      this.nodeChild1 = this.getNode(node.ChildIDs[0]);
      this.nodeChild2 = this.getNode(node.ChildIDs[1]);
      this.nodeChild3 = this.getNode(node.ChildIDs[2]);
      this.nodeChild4 = this.getNode(node.ChildIDs[3]);
      this.nodeChild5 = this.getNode(node.ChildIDs[4]);
      this.nodeChild6 = null;
    } else if (this.numChildren == 6) { // six child case
      this.nodeChild1 = this.getNode(node.ChildIDs[0]);
      this.nodeChild2 = this.getNode(node.ChildIDs[1]);
      this.nodeChild3 = this.getNode(node.ChildIDs[2]);
      this.nodeChild4 = this.getNode(node.ChildIDs[3]);
      this.nodeChild5 = this.getNode(node.ChildIDs[4]);
      this.nodeChild6 = this.getNode(node.ChildIDs[5]);
    } else {
      console.log('More than 6 nodes...');
    }
     */

  }

  /** gets node based on index of array */
  getNode(id:number): Node {
    console.log("Beginning", this.backendService.getNode(id));
    /**trying the map function to set the values */

    this.backendService.getNode(id)
    .subscribe(node => {
          console.log("Logging inside", node);
          this.testNode = node;
          console.log("IS test node set inside?", this.testNode);
          this.helperFunction(node);
          //return this.testNode;
          //this.curNode = node;
        });
        console.log("IS test node set outside?", this.testNode);
        return this.testNode;
    //console.log("This is the node: ", this.curNode);
    //return this.curNode;
  }

  helperFunction(node:Node) {
    console.log("inside helper: ", node);
    this.curNode = node;
    console.log("This is curNode: ", this.curNode);
    this.createView(node);

  }

  /**Pulls batch of nodes from the organization */
  getOrg(root:Node) {
    this.org.push(root);
    this.childrenTemp = root.ChildIDs;
    for (let index = 0; index < this.childrenTemp.length; index++) {
      const id = this.childrenTemp[index];
      this.backendService.getNode(id)
          .subscribe(node => this.org.push(node));
      
    }

  }

  /**when a node is clicked, call this method */
  nodeClicked(node:Node) {
    this.createView(node);
    // this.org[nodeID].clicked = true; // change value for the organization itself
    // this.user.nodesClicked.push(nodeID);
    // console.log(this.org, this.org[nodeID].clicked);
    // console.log(this.user.nodesClicked);
    // //create new view with the clicked nodde as the current position/current node
    // //calculate indexes of "mountains"
    
    // this.computeIndex(nodeID);
    // this.createView(nodeID, this.leftNodeID, this.rightNodeID, this.midNodeID);
    // //Create new view
    

  }

  computeIndex(nodeID:number){
    this.leftNodeID = (2*nodeID+1);
    this.rightNodeID = (2*nodeID);
    this.midNodeID = (4*nodeID);
    //index checking, implement more random selection of leaf nodes later
    if(this.leftNodeID > this.sizeOfOrg){
      this.leftNodeID = this.sizeOfOrg;                                    
    }
    if(this.rightNodeID > this.sizeOfOrg){
      this.rightNodeID = this.sizeOfOrg;
    }
    if(this.midNodeID > this.sizeOfOrg){
      this.midNodeID = this.sizeOfOrg;
    }
  }

  /**Create View 
  createView(curNodeID:number, leftNodeID:number, rightNodeID:number, midNodeID:number){
    this.curNode = this.org[curNodeID];
    this.leftNode = this.org[this.leftNodeID];
    this.rightNode = this.org[this.rightNodeID];
    this.midNode = this.org[this.midNodeID];

  }*/

  /**Adds dataset node id to list of marked datasets for the user 
   * directs user to add connection page to add the database connection
  */
  datasetMarked(nodeID:number){
    console.log("dataset marked!", nodeID);
    this.user.dbMarked.push(nodeID); // add nodeID to marked datasets list
    console.log(this.user.dbMarked)
    this.router.navigate(['add-connection']); //navigate user to add the database connection
  
  }

  /**Does not add the database to list of marked datasets
   * Redirects user to root of organization
   */
  datasetNotMarked(){
    console.log("dataset NOT marked!")
    this.curNode = this.org[0];
    // this.leftNode = this.org[1];
    // this.rightNode = this.org[2];
    // this.midNode = this.org[3];
    // this.router.navigate(['nav']); //navigate user to add the database connection
  }

}
